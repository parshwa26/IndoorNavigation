package io.mapwize.mapwize;

public interface MWZDirectionPoint {

    MWZDirectionPointWrapper toDirectionWrapper();

}
