package io.mapwize.mapwize;

import android.support.annotation.Nullable;

public interface LoadURLCallbackInterface {

    void onResponse(@Nullable Error error);

}
