package io.mapwize.example;

public class CenterNames {
    private String place_name;
    private int pic_id;
    private int imgBackCol;
    private Boolean isEnable;

    public CenterNames(String place_name, int imgBackCol, Boolean isEnable) {
        this.place_name = place_name;
        this.pic_id = pic_id;
        this.imgBackCol = imgBackCol;
        this.isEnable = isEnable;
    }

    public void setPlace_name(String place_name) {
        this.place_name = place_name;
    }

    public void setPic_id(int pic_id) {
        this.pic_id = pic_id;
    }

    public void setImgBackCol(int imgBackCol) {
        this.imgBackCol = imgBackCol;
    }

    public void setIsEnable(Boolean imgBackCol) {
        this.isEnable = isEnable;
    }

    public String getPlace_name() {
        return place_name;
    }

    public int getPic_id() {
        return pic_id;
    }

    public int getImgBackCol() {
        return imgBackCol;
    }

    public Boolean getIsEnable() {
        return isEnable;
    }

}