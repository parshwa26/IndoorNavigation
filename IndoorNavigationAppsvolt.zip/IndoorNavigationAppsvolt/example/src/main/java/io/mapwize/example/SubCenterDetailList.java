package io.mapwize.example;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class SubCenterDetailList extends AppCompatActivity {

    private ListView subCenterDetailList;
    private ListSubCenterDetailViewAdapter subCenterDetailAdapter;


    private String[] subCenterDetailNameList;
    private String languageId;

    private int[] subCenterColorDetailList;

    public static ArrayList<CenterNames> subCenterDetailNamesArrayList = new ArrayList<CenterNames>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_center_detail_list);

        Intent intent = getIntent();
        languageId = intent.getStringExtra("selectedLanguage");

        if (languageId.equals("EN")) {
            subCenterDetailNameList = new String[]{"Legal Opinion and Legislation Section",
                    "Cases and Investigations Section"};
        } else {
            subCenterDetailNameList = new String[]{"قسم الرأي القانوني و التشريعات",
                    "قسم القضايا والتحقيقات"};
        }

        subCenterColorDetailList = new int[]{Color.rgb(213, 99, 37),
                Color.rgb(213, 99, 37)};

        // Locate the ListView in listview_main.xml
        subCenterDetailList = (ListView) findViewById(R.id.sub_center_detail_listview_listview);

        subCenterDetailNamesArrayList = new ArrayList<>();
        //place_pics = getResources().obtainTypedArray(R.array.place_image);
        for (int i = 0; i < subCenterDetailNameList.length; i++) {
            CenterNames cent = new CenterNames(subCenterDetailNameList[i],subCenterColorDetailList[i],true);
            // Binds all strings into an array
            subCenterDetailNamesArrayList.add(cent);
        }

        // Pass results to io.mapwize.mapwizesimpleapplication.button.ListCenterViewAdapter Class
        subCenterDetailAdapter = new ListSubCenterDetailViewAdapter(this);

        // Binds the Adapter to the ListView
        subCenterDetailList.setAdapter(subCenterDetailAdapter);

        subCenterDetailList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if(position == 0){
                    Intent intent = new Intent(SubCenterDetailList.this, MainActivity.class);
                    intent.putExtra("placeid","5d233d8ab7e7d80016db9f3d");
                    startActivity(intent);
                }if(position == 1){
                    Intent intent = new Intent(SubCenterDetailList.this, MainActivity.class);
                    intent.putExtra("placeid","5d233d9ab7e7d80016db9f3f");
                    startActivity(intent);
                }
            }
        });
    }
}
