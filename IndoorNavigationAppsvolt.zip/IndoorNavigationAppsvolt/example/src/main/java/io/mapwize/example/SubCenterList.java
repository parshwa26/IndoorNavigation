package io.mapwize.example;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class SubCenterList extends AppCompatActivity {

    private ListView subCenterList;
    private ListSubCenterViewAdapter subCenterAdapter;


    private String[] subCenterNameList;
    private String languageId;

    private int[] subCenterColorList;

    public static ArrayList<CenterNames> subCenterNamesArrayList = new ArrayList<CenterNames>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_center_list);

        Intent intent = getIntent();
        languageId = intent.getStringExtra("selectedLanguage");

        if (languageId.equals("EN")) {
            subCenterNameList = new String[]{"Office of the Director General",
                    "Office for Program Implementation Overseeing",
                    "Department of Legal Affairs",
                    "Internal Audit Office",
                    "Director of Investment Office"};
        } else {
            subCenterNameList = new String[]{"مكتب المدير العام",
                    "مكتب مراقبة تنفيذ البرامج",
                    "ادارة الشؤون القانونية",
                    "مكتب التدقيق الداخلي",
                    "مدير مكتب الاستثمار"};
        }

        subCenterColorList = new int[]{Color.rgb(213, 99, 37),
                Color.rgb(213, 99, 37),
                Color.rgb(213, 99, 37),
                Color.rgb(213, 99, 37),
                Color.rgb(213, 99, 37)};

        // Locate the ListView in listview_main.xml
        subCenterList = (ListView) findViewById(R.id.sub_center_listview);

        subCenterNamesArrayList = new ArrayList<>();
        //place_pics = getResources().obtainTypedArray(R.array.place_image);
        for (int i = 0; i < subCenterNameList.length; i++) {
            if (i == 2) {
                CenterNames cent = new CenterNames(subCenterNameList[i],subCenterColorList[i],true);
                // Binds all strings into an array
                subCenterNamesArrayList.add(cent);
            } else {
                CenterNames cent = new CenterNames(subCenterNameList[i],subCenterColorList[i],false);
                // Binds all strings into an array
                subCenterNamesArrayList.add(cent);
            }
        }

        // Pass results to io.mapwize.mapwizesimpleapplication.button.ListCenterViewAdapter Class
        subCenterAdapter = new ListSubCenterViewAdapter(this);

        // Binds the Adapter to the ListView
        subCenterList.setAdapter(subCenterAdapter);

        subCenterList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if (position == 2) {
                    //SENDING DATA TO ANOTHER ACTIVITY
                    Intent intent = new Intent(SubCenterList.this, SubCenterDetailList.class);
                    intent.putExtra("selectedLanguage", languageId);
                    startActivity(intent);
//                    Toast.makeText(SubCenterList.this, subCenterNamesArrayList.get(position).getPlace_name(), Toast.LENGTH_SHORT).show();
                }
                if (position == 0){
                    Intent intent = new Intent(SubCenterList.this, MainActivity.class);
                    intent.putExtra("placeid","5d233ca4214302002d1e9fa2");
                    startActivity(intent);
                }
                if (position == 1){
                    Intent intent = new Intent(SubCenterList.this, MainActivity.class);
                    intent.putExtra("placeid","5d233cf3214302002d1e9fad");
                    startActivity(intent);
                }
                if (position == 3){
                    Intent intent = new Intent(SubCenterList.this, MainActivity.class);
                    intent.putExtra("placeid","5d233d2896fcf8001640d687");
                    startActivity(intent);
                }
                if (position == 4){
                    Intent intent = new Intent(SubCenterList.this, MainActivity.class);
                    intent.putExtra("placeid","5d233d41362027002d79975d");
                    startActivity(intent);
                }
            }
        });
    }

}
