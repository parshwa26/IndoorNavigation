# Deprecated

This is the former version of the Mapwize Android SDK.

It is still supported for clients in production but all new clients are strongly advised to use the newest Android SDK.

The newest SDKs are available on [docs.mapwize.io](https://docs.mapwize.io/doc/).


